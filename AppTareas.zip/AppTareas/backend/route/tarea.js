//modulos internos

const express= require("express");
const router= express.Router();

const {Tarea}= require("../model/tarea");
const {Usuario} = require("../model/usuario");

const autenticacion= require("../middleware/autenticacion");

//ruta

router.post("/",autenticacion,async(req, res)=> {

	//definimos el id del usuario validado
	const usuario= await Usuario.findById(req.usuario._id);

	//en caso que no exista el usuario
	if (!usuario) return res.status(400).send("El usuario no existe en la base de datos");

	//si el usuario existe insertamos la tarea con su id 

	const tarea= new Tarea ({

		idUsuario: usuario._id,
		titulo: req.body.titulo,
		descripcion: req.body.descripcion,
		estado: req.body.estado,
	});

	//enviamos el objeto
	const result= await tarea.save();
	res.status(200).send(result);

});

//exports
module.exports = router;

