// modulos internos

const mongoose= require("mongoose");
const jwt= require("jsonwebtoken");

//esquema

const esquemaTarea= new mongoose.Schema({

	idUsuario: String,
	titulo: String,
	descripcion: String,
	estado: String,
	fecha: {
		type: Date,
		default: Date.now,
	}

});

//exports

const Tarea= mongoose.model("tarea",esquemaTarea);
module.exports.Tarea= Tarea;

